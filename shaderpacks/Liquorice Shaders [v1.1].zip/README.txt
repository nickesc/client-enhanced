// [ Introduction ]
Hello! Thank you for downloading this shaderpack. 
Lot's of effort went into its creation!


// [ For Assistance ]
If you need help installing shaders, 
please watch this youtube tutorial: https://www.youtube.com/watch?v=3fRlEooz1bU
This video explains every step that is necessary 
to install Minecraft shaders.


// [ For Creators ]
If you are a creator, and wish to create a new work
derived from this project, make sure to read
'LICENSE.txt' prior to copying the project. There
are terms that you must agree with before
re-using the source code.
